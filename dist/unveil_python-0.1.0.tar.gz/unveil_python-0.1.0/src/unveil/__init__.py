"""
This package contains an UNVEIL, a lightweight tractography viewer implemented in python."""

__version__ = "0.1.0"
__author__ = 'Nicolas Delinte'