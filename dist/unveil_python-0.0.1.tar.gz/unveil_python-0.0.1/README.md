# UNVEIL
A simple tractography viewer implemented in python.

![image](https://github.com/user-attachments/assets/4fbefa7a-3fc2-446a-8835-2844266b14fa)
