# -*- coding: utf-8 -*-
"""
Created on Tue Mar  4 13:03:28 2025

@author: DELINTE Nicolas
"""
import sys
import numpy as np
import nibabel as nib
import pyvista as pv
from pyvistaqt import QtInteractor
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (QApplication, QWidget, QHBoxLayout, QVBoxLayout,
                             QPushButton, QFileDialog, QCheckBox, QSlider,
                             QLabel, QComboBox, QMainWindow,
                             QDockWidget, QTreeWidget, QTreeWidgetItem,
                             QColorDialog, QTabWidget, QDoubleSpinBox,
                             QGroupBox)
from PyQt6.QtGui import QAction, QColor
from dipy.io.streamline import load_tractogram
from matplotlib import pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.figure import Figure
# from unravel.utils import get_streamline_density
from unveil.utils import dilate_atlas_labels


def gifti_to_pyvista(gii_path):
    """
    Load a GIFTI surface and transform coordinates into voxel space
    using the inverse of the given NIfTI affine.
    """

    # Load GIFTI file
    img = nib.load(gii_path)
    coords_list = img.get_arrays_from_intent('NIFTI_INTENT_POINTSET')
    face_list = img.get_arrays_from_intent('NIFTI_INTENT_TRIANGLE')

    if len(coords_list) == 0 or len(face_list) == 0:
        raise RuntimeError(
            "Could not find POINTSET or TRIANGLE arrays in GIFTI file.")

    # Extract data
    coords_world = coords_list[0].data.astype(np.float32)
    faces = face_list[0].data.astype(np.int32)

    # Build PyVista face array (VTK expects [3, i1, i2, i3, 3, ...])
    faces_pv = np.hstack(
        (np.full((faces.shape[0], 1), 3, dtype=np.int32), faces)).astype(np.int32)

    # Create PolyData mesh in voxel space
    mesh = pv.PolyData(coords_world, faces_pv)

    return mesh


def convert_rgb_array_to_new_basis(rgb_array):
    """
    Converts an array of RGB colors shape [n, 3] into a new basis.

    rgb_array: numpy array of shape (n, 3) where each row is [R, G, B]
    Returns: numpy array of shape (n, 3) where each row is [newR, newG, newB]
    """

    # Based on the Color-Blind Safe IBM Design Library Color Palette
    C1 = np.array([220, 38, 127])
    C2 = np.array([255, 176, 0])
    C3 = np.array([120, 94, 240])

    B = np.column_stack([C1, C2, C3])
    new_rgb = rgb_array.dot(B.T)

    return new_rgb


def plot_trk(trk_file, scalar=None, color_map='plasma', opacity: float = 1,
             show_points: bool = False, background: str = 'black', plotter=None,
             name=None, reset_camera=False, color_blind: bool = False):
    '''
    3D render for .trk files.

    Parameters
    ----------
    trk_file : str
        Path to tractography file (.trk)
    scalar : 3D array of size (x,y,z), optional
        Volume with values to be projected onto the streamlines.
        The default is None.
    opacity : float, optional
        DESCRIPTION. The default is 1.
    show_points : bool, optional
        Enable to show points instead of lines. The default is False.
    color_map : str, optional
        Color map for the labels or scalar. 'Set3' or 'tab20' recommend for
        segmented color maps. If set to 'flesh', the streamlines are colored
        uniformely with a flesh color. The default is 'plasma'.
    background : str, optional
        Color of the background. The default is 'black'.
    plotter : pyvista.plotter, optional
        If not specifed, creates a new figure. The default is None.

    Returns
    -------
    None.

    '''

    trk = load_tractogram(trk_file, 'same')
    trk.to_vox()
    trk.to_corner()
    streamlines = trk.streamlines

    coord = np.floor(streamlines._data).astype(int)

    l1 = np.ones(len(coord))*2
    l2 = np.linspace(0, len(coord)-1, len(coord))
    l3 = np.linspace(1, len(coord), len(coord))

    lines = np.stack((l1, l2, l3), axis=-1).astype(int)
    lines[streamlines._offsets-1] = 0

    mesh = pv.PolyData(streamlines._data)

    if not show_points:
        mesh.lines = lines
        point_size = 0
        ambient = 0.6
        diffuse = 0.5
    else:
        point_size = 2
        ambient = 0
        diffuse = 1

    if color_map == 'flesh':
        rgb = False
    elif scalar is None:
        point = streamlines._data
        next_point = np.roll(point, -1, axis=0)
        vs = next_point-point
        ends = (streamlines._offsets+streamlines._lengths-1)
        if color_blind:
            vs = convert_rgb_array_to_new_basis(np.abs(vs))
        norm = np.linalg.norm(vs, axis=1)
        norm = np.stack((norm,)*3, axis=1, dtype=np.float32)
        norm = np.divide(vs, norm, dtype=np.float64)
        norm[ends, :] = norm[ends-1, :]
        scalars = np.abs(norm)
        rgb = True
    else:
        scalars = scalar[coord[:, 0], coord[:, 1], coord[:, 2]]
        rgb = False

    if plotter is None:
        p = pv.Plotter()
    else:
        p = plotter

    if 'tab' in color_map or 'Set' in color_map:

        N = np.max(scalar)
        cmaplist = getattr(plt.cm, color_map).colors
        cmaplistext = cmaplist*np.ceil(N/len(cmaplist)).astype(int)
        color_map = LinearSegmentedColormap.from_list('Custom cmap',
                                                      cmaplistext[:N], N)
        color_lim = [1, N]

        p.add_mesh(mesh, ambient=ambient, opacity=opacity, diffuse=diffuse,
                   interpolate_before_map=False, render_lines_as_tubes=True,
                   line_width=2, point_size=point_size, rgb=rgb,
                   cmap=color_map, clim=color_lim, scalars=scalars, name=name,
                   reset_camera=reset_camera, user_matrix=trk.affine)

    elif color_map == 'flesh':
        p.add_mesh(mesh, opacity=opacity, diffuse=0.4, ambient=ambient,
                   interpolate_before_map=False, render_lines_as_tubes=True,
                   line_width=2, point_size=point_size, rgb=rgb,
                   color=[250, 225, 210], name=name,
                   reset_camera=reset_camera, user_matrix=trk.affine)
    else:
        p.add_mesh(mesh, opacity=opacity, diffuse=diffuse, ambient=ambient,
                   interpolate_before_map=False, render_lines_as_tubes=True,
                   line_width=2, point_size=point_size, rgb=rgb,
                   cmap=color_map, scalars=scalars, name=name,
                   reset_camera=reset_camera, user_matrix=trk.affine)

    p.background_color = background


def load_gii_data(gii_path):
    """
    Load all data contained in the GifTi file except vertex coordinates and triangles.
    Returns : dictionnary {"Gii table name" : data}
    """
    gii_img = nib.load(gii_path)
    vertex_coords = gii_img.get_arrays_from_intent(
        "NIFTI_INTENT_POINTSET")[0].data
    gii_data = {}

    # Iterate over all tables of the GIfTI
    for darray in gii_img.darrays:
        # Vertex coords and triangles are stored with None as 'Name'
        if darray.meta.get("Name") is not None:
            # Check that the table contains 1 value per vertex
            if darray.data.shape == vertex_coords[:, 0].shape:
                gii_data[darray.meta.get("Name")] = darray.data

    return gii_data


class TrkViewer(QWidget):
    def __init__(self):
        super().__init__()
        self.nii_data = None
        self.grid = None
        self.actor_types = {}
        self.x = 0
        self.y = 0
        self.z = 0
        self.colormap_list = ['gray',
                              'viridis', 'plasma', 'inferno', 'magma', 'cividis',
                              'Greys', 'Purples', 'Blues', 'Greens', 'Oranges',
                              'Reds', 'bone', 'pink', 'spring', 'summer',
                              'autumn', 'winter', 'cool', 'Wistia', 'hot',
                              'afmhot', 'gist_heat', 'copper', 'YlOrRd', 'YlOrBr',
                              'RdBu', 'RdYlBu',
                              'RdYlGn', 'Spectral', 'coolwarm', 'bwr', 'seismic',
                              'berlin', 'managua', 'vanimo', 'twilight',
                              'twilight_shifted', 'hsv', 'Pastel1', 'Pastel2',
                              'Paired', 'Accent', 'okabe_ito', 'Dark2', 'Set1',
                              'Set2', 'Set3', 'tab10', 'tab20', 'tab20b', 'tab20c',
                              'flag', 'prism', 'ocean', 'gist_earth', 'terrain',
                              'gist_stern', 'gnuplot', 'gnuplot2', 'CMRmap',
                              'cubehelix', 'brg', 'gist_rainbow', 'rainbow',
                              'jet', 'turbo', 'nipy_spectral', 'gist_ncar']
        self.initUI()
        self.background = 'white'
        self.color_blind = False
        self.flicker = False
        self.roi_colors = {}
        self.roi_volumes = {}
        self.roi_visibility = {}

    def initUI(self):
        # Create the main layout
        global_layout = QVBoxLayout(self)

        # Camera toolbar (buttons for orientation)
        camera_label = QLabel('Camera: ')
        cam_layout = QHBoxLayout()
        btn_iso = QPushButton("Isometric")
        btn_xy = QPushButton("Axe 1")
        btn_xz = QPushButton("Axe 2")
        btn_yz = QPushButton("Axe 3")
        btn_iso.clicked.connect(lambda: self.set_view("view_isometric"))
        btn_xy.clicked.connect(lambda: self.set_view("view_xy"))
        btn_xz.clicked.connect(lambda: self.set_view("view_xz"))
        btn_yz.clicked.connect(lambda: self.set_view("view_yz"))
        cam_layout.addWidget(camera_label)
        cam_layout.addWidget(btn_iso)
        cam_layout.addWidget(btn_xy)
        cam_layout.addWidget(btn_xz)
        cam_layout.addWidget(btn_yz)
        btn_screenshot = QPushButton("Screenshot")
        btn_screenshot.clicked.connect(self.take_screenshot)
        cam_layout.addWidget(btn_screenshot)
        btn_gif = QPushButton("Create GIF")
        btn_gif.setToolTip("This takes ~2min to save after animation end.")
        btn_gif.clicked.connect(self.create_gif)
        cam_layout.addWidget(btn_gif)

        global_layout.addLayout(cam_layout)

        main_layout = QHBoxLayout()
        global_layout.addLayout(main_layout)

        # Left side: Control panel
        control_widget = QWidget()
        control_layout = QVBoxLayout(control_widget)
        control_widget.setMaximumWidth(260)

        # Tractography
        trk_group = QGroupBox("TRK / Tractography")
        trk_layout = QVBoxLayout(trk_group)

        opacity_trk_row = QHBoxLayout()
        opacity_trk_row.setSpacing(5)
        self.opacityLabel = QLabel('Opacity:')
        opacity_trk_row.addWidget(self.opacityLabel)
        self.opacitySlider = QSlider(Qt.Orientation.Horizontal, self)
        self.opacitySlider.setMinimum(1)
        self.opacitySlider.setMaximum(100)
        self.opacitySlider.setValue(100)
        self.opacitySlider.sliderReleased.connect(self.update_trk_viewer)
        opacity_trk_row.addWidget(self.opacitySlider)
        trk_layout.addLayout(opacity_trk_row)

        color_mode_trk_row = QHBoxLayout()
        color_mode_trk_row.setSpacing(5)
        self.colorMapLabel = QLabel('Color Mode:')
        color_mode_trk_row.addWidget(self.colorMapLabel)
        self.colorMapComboBox = QComboBox()
        self.colorMapComboBox.addItems(['rgb', 'flesh', 'scalar'])
        self.colorMapComboBox.currentIndexChanged.connect(
            self.update_trk_viewer)
        color_mode_trk_row.addWidget(self.colorMapComboBox)
        trk_layout.addLayout(color_mode_trk_row)

        colormap_trk_row = QHBoxLayout()
        colormap_trk_row.setSpacing(5)
        self.tractColorMapLabel = QLabel('Colormap (Scalar):')
        colormap_trk_row.addWidget(self.tractColorMapLabel)
        self.tractColorMapComboBox = QComboBox()
        self.tractColorMapComboBox.addItems(self.colormap_list)
        self.tractColorMapComboBox.currentIndexChanged.connect(
            self.update_trk_viewer)
        colormap_trk_row.addWidget(self.tractColorMapComboBox)
        trk_layout.addLayout(colormap_trk_row)

        self.showPointsCheckbox = QCheckBox('Show Points')
        self.showPointsCheckbox.stateChanged.connect(self.update_trk_viewer)
        trk_layout.addWidget(self.showPointsCheckbox)

        control_layout.addWidget(trk_group)

        # Volume
        nii_group = QGroupBox("NIfTI / Volume")
        nii_layout = QVBoxLayout(nii_group)

        opacity_nii_row = QHBoxLayout()
        opacity_nii_row.setSpacing(5)
        self.volume_label = QLabel('Opacity:')
        opacity_nii_row.addWidget(self.volume_label)
        self.nii_opacitySlider = QSlider(Qt.Orientation.Horizontal, self)
        self.nii_opacitySlider.setMinimum(0)
        self.nii_opacitySlider.setMaximum(1000)
        self.nii_opacitySlider.setValue(45)
        self.nii_opacitySlider.sliderReleased.connect(self.update_nii_viewer)
        opacity_nii_row.addWidget(self.nii_opacitySlider)
        nii_layout.addLayout(opacity_nii_row)

        colormap_nii_row = QHBoxLayout()
        colormap_nii_row.setSpacing(5)
        self.niiColorMapLabel = QLabel('Colormap:')
        colormap_nii_row.addWidget(self.niiColorMapLabel)
        self.niiColorMapComboBox = QComboBox()
        self.niiColorMapComboBox.addItems(self.colormap_list)
        self.niiColorMapComboBox.currentIndexChanged.connect(
            self.on_nii_colormap_changed)
        colormap_nii_row.addWidget(self.niiColorMapComboBox)
        nii_layout.addLayout(colormap_nii_row)

        nii_range_layout = QHBoxLayout()

        nii_min_layout = QVBoxLayout()
        self.niiMinLabel = QLabel('Min:')
        self.niiMinSpinBox = QDoubleSpinBox()
        self.niiMinSpinBox.setDecimals(2)
        self.niiMinSpinBox.setRange(-1e6, 1e6)
        self.niiMinSpinBox.setSingleStep(0.1)
        self.niiMinSpinBox.setValue(0.0)
        self.niiMinSpinBox.editingFinished.connect(self.update_nii_viewer)
        nii_min_layout.addWidget(self.niiMinLabel)
        nii_min_layout.addWidget(self.niiMinSpinBox)

        nii_max_layout = QVBoxLayout()
        self.niiMaxLabel = QLabel('Max:')
        self.niiMaxSpinBox = QDoubleSpinBox()
        self.niiMaxSpinBox.setDecimals(2)
        self.niiMaxSpinBox.setRange(-1e6, 1e6)
        self.niiMaxSpinBox.setSingleStep(0.1)
        self.niiMaxSpinBox.setValue(1.0)
        self.niiMaxSpinBox.editingFinished.connect(self.update_nii_viewer)
        nii_max_layout.addWidget(self.niiMaxLabel)
        nii_max_layout.addWidget(self.niiMaxSpinBox)

        nii_range_layout.addLayout(nii_min_layout)
        nii_range_layout.addLayout(nii_max_layout)
        nii_layout.addLayout(nii_range_layout)

        self.showSlicesCheckbox = QCheckBox('Show Slices')
        self.showSlicesCheckbox.stateChanged.connect(self.update_nii_viewer)
        nii_layout.addWidget(self.showSlicesCheckbox)

        x_nii_row = QHBoxLayout()
        x_nii_row.setSpacing(5)
        self.x_label = QLabel('X:')
        x_nii_row.addWidget(self.x_label)
        self.XSlider = QSlider(Qt.Orientation.Horizontal, self)
        self.XSlider.setMinimum(0)
        self.XSlider.setMaximum(100)
        self.XSlider.setValue(100)
        self.XSlider.sliderReleased.connect(
            lambda: self._update_slice('x', 'nii_x'))
        x_nii_row.addWidget(self.XSlider)
        nii_layout.addLayout(x_nii_row)
        y_nii_row = QHBoxLayout()
        y_nii_row.setSpacing(5)
        self.y_label = QLabel('Y:')
        y_nii_row.addWidget(self.y_label)
        self.YSlider = QSlider(Qt.Orientation.Horizontal, self)
        self.YSlider.setMinimum(0)
        self.YSlider.setMaximum(100)
        self.YSlider.setValue(100)
        self.YSlider.sliderReleased.connect(
            lambda: self._update_slice('y', 'nii_y'))
        y_nii_row.addWidget(self.YSlider)
        nii_layout.addLayout(y_nii_row)
        z_nii_row = QHBoxLayout()
        z_nii_row.setSpacing(5)
        self.z_label = QLabel('Z:')
        z_nii_row.addWidget(self.z_label)
        self.ZSlider = QSlider(Qt.Orientation.Horizontal, self)
        self.ZSlider.setMinimum(0)
        self.ZSlider.setMaximum(100)
        self.ZSlider.setValue(100)
        self.ZSlider.sliderReleased.connect(
            lambda: self._update_slice('z', 'nii_z'))
        z_nii_row.addWidget(self.ZSlider)
        nii_layout.addLayout(z_nii_row)

        control_layout.addWidget(nii_group)

        # Gifti
        gii_group = QGroupBox("GIFTI / Surface")
        gii_layout = QVBoxLayout(gii_group)

        opacity_gii_row = QHBoxLayout()
        opacity_gii_row.setSpacing(5)
        self.gii_opacityLabel = QLabel('Opacity:')
        opacity_gii_row.addWidget(self.gii_opacityLabel)
        self.gii_opacitySlider = QSlider(Qt.Orientation.Horizontal, self)
        self.gii_opacitySlider.setMinimum(0)
        self.gii_opacitySlider.setMaximum(100)
        self.gii_opacitySlider.setValue(15)
        self.gii_opacitySlider.sliderReleased.connect(self.update_gii_viewer)
        opacity_gii_row.addWidget(self.gii_opacitySlider)
        gii_layout.addLayout(opacity_gii_row)

        color_mode_gii_row = QHBoxLayout()
        color_mode_gii_row.setSpacing(5)
        self.giiColorModeLabel = QLabel('Color Mode:')
        color_mode_gii_row.addWidget(self.giiColorModeLabel)
        self.giiColorModeComboBox = QComboBox()
        self.giiColorModeComboBox.addItems(['Solid', 'NIfTI values'])
        self.giiColorModeComboBox.currentIndexChanged.connect(
            lambda index: self.update_gii_viewer(update_color_range=True))
        color_mode_gii_row.addWidget(self.giiColorModeComboBox)
        gii_layout.addLayout(color_mode_gii_row)

        colormap_gii_row = QHBoxLayout()
        colormap_gii_row.setSpacing(5)
        self.giiColorMapLabel = QLabel('Colormap:')
        colormap_gii_row.addWidget(self.giiColorMapLabel)
        self.giiColorMapComboBox = QComboBox()
        self.giiColorMapComboBox.addItems(self.colormap_list)
        self.giiColorMapComboBox.setCurrentText('viridis')
        self.giiColorMapComboBox.currentIndexChanged.connect(
            self.update_gii_viewer)
        colormap_gii_row.addWidget(self.giiColorMapComboBox)
        gii_layout.addLayout(colormap_gii_row)

        gii_range_layout = QHBoxLayout()

        gii_min_layout = QVBoxLayout()
        self.giiMinLabel = QLabel('Min:')
        self.giiMinSpinBox = QDoubleSpinBox()
        self.giiMinSpinBox.setDecimals(2)
        self.giiMinSpinBox.setRange(-1e6, 1e6)
        self.giiMinSpinBox.setSingleStep(0.1)
        self.giiMinSpinBox.setValue(0.0)
        self.giiMinSpinBox.editingFinished.connect(self.update_gii_viewer)
        gii_min_layout.addWidget(self.giiMinLabel)
        gii_min_layout.addWidget(self.giiMinSpinBox)

        gii_max_layout = QVBoxLayout()
        self.giiMaxLabel = QLabel('Max:')
        self.giiMaxSpinBox = QDoubleSpinBox()
        self.giiMaxSpinBox.setDecimals(2)
        self.giiMaxSpinBox.setRange(-1e6, 1e6)
        self.giiMaxSpinBox.setSingleStep(0.1)
        self.giiMaxSpinBox.setValue(1.0)
        self.giiMaxSpinBox.editingFinished.connect(self.update_gii_viewer)
        gii_max_layout.addWidget(self.giiMaxLabel)
        gii_max_layout.addWidget(self.giiMaxSpinBox)

        gii_range_layout.addLayout(gii_min_layout)
        gii_range_layout.addLayout(gii_max_layout)
        gii_layout.addLayout(gii_range_layout)

        control_layout.addWidget(gii_group)

        self.update_surface_color_controls()

        # Add the control panel layout to the main layout
        main_layout.addWidget(control_widget)

        # Right side: PyVista viewer embedded in the GUI using QtInteractor
        self.plotter = QtInteractor(self)
        main_layout.addWidget(self.plotter.interactor)

        self.setLayout(global_layout)
        self.setWindowTitle("Tractography Viewer")

    def loadTrkFile(self):
        options = QFileDialog.Options()
        filePaths, _ = QFileDialog.getOpenFileNames(self, "Open TRK Files", "",
                                                    "Tractography Files (*.trk)",
                                                    options=options)
        if not filePaths:
            return

        for trk_path in filePaths:
            print(f"Loaded TRK file: {trk_path}")
            self.actor_types[trk_path] = 'trk'

        self.update_trk_viewer(reset_camera=True)
        self.window().refreshActorList()

    def loadNiftiFile(self):
        options = QFileDialog.Options()
        filePath, _ = QFileDialog.getOpenFileName(
            self, "Open .nii.gz File", "", "Nifti Files (*.nii.gz)", options=options)

        if not filePath:
            return

        print(f"Loaded NIfTI file: {filePath}")
        img = nib.load(filePath)
        self.nii_affine = img.affine
        self.nii_data = img.get_fdata()

        self.update_volume_color_range_from_nifti()

        grid = pv.ImageData()
        grid.dimensions = np.array(self.nii_data.shape) + 1
        grid.cell_data['values'] = self.nii_data.flatten(order='F')
        self.grid = grid

        self.XSlider.setMaximum(self.nii_data.shape[0])
        self.YSlider.setMaximum(self.nii_data.shape[1])
        self.ZSlider.setMaximum(self.nii_data.shape[2])

        self.update_nii_viewer(reset_camera=False)

        # Dilation for surface
        self.nii_data_dilated = dilate_atlas_labels(
            self.nii_data, dilation_width=4)
        self.nii_data_dilated = np.where(self.nii_data_dilated == 0, np.nan,
                                         self.nii_data_dilated)

        if hasattr(self, "gii_mesh"):
            # Sample NIfTI values at each surface vertex
            self.nii_surface_values = self.sample_nifti_on_surface(
                self.gii_mesh)
            self.update_gii_viewer(reset_camera=False)
        else:
            self.nii_surface_values = None
        self.window().refreshActorList()

        # Update 2D view with current colormap
        ortho_data = self.nii_data.copy()
        ortho_data[ortho_data == 0] = None

        self.window().ortho_viewer.set_volume(ortho_data, self.nii_affine)
        self.window().ortho_viewer.set_colormap(self.niiColorMapComboBox.currentText())

    def loadROIFile(self):
        """Load one or multiple ROI nifti volumes and render as surfaces."""
        options = QFileDialog.Options()
        filePaths, _ = QFileDialog.getOpenFileNames(self, "Open ROI Files", "",
                                                    "Nifti Files (*.nii *.nii.gz)",
                                                    options=options)

        if not filePaths:
            return

        for roi_path in filePaths:
            img = nib.load(roi_path)
            roi = img.get_fdata()

            datapv = pv.wrap(roi)
            datapv.cell_data['labels'] = roi[:-1, :-1, :-1].flatten(order='F')
            vol = datapv.threshold(value=1, scalars='labels')
            mesh = vol.extract_surface()

            smooth = mesh.smooth_taubin(n_iter=12)

            actor_name = f"{roi_path.split('/')[-1]}"
            self.actor_types[actor_name] = "roi"
            self.roi_volumes[actor_name] = roi
            self.roi_visibility[actor_name] = True

            default_color = np.array([1.0, 1.0, 1.0])

            self.roi_colors[actor_name] = default_color

            self.plotter.add_mesh(smooth, name=actor_name, opacity=1,
                                  color=default_color, user_matrix=img.affine,
                                  reset_camera=False, point_size=0,
                                  render_lines_as_tubes=True)

            self.window().refreshActorList()

            self.window().ortho_viewer.add_roi(actor_name, roi, default_color)

    def loadGiftiFile(self):
        options = QFileDialog.Options()
        filePath, _ = QFileDialog.getOpenFileName(
            self, "Open .gii File", "", "Gifti Files (*.gii)", options=options)

        if not filePath:
            return

        print(f"Loaded GIFTI file: {filePath}")

        self.gii_mesh = gifti_to_pyvista(filePath)

        self.gii_data = load_gii_data(filePath)

        self.giiColorModeComboBox.setCurrentIndex(0)

        for _ in range(self.giiColorModeComboBox.count()-2):
            self.giiColorModeComboBox.removeItem(2)

        self.giiColorModeComboBox.addItems(list(self.gii_data.keys()))

        self.actor_types["gii_surface"] = "gii"

        if hasattr(self, "nii_data"):
            # Sample NIfTI values at each surface vertex
            self.nii_surface_values = self.sample_nifti_on_surface(
                self.gii_mesh)
            self.update_gii_viewer(reset_camera=False)
        else:
            self.nii_surface_values = None

        self.update_gii_viewer(reset_camera=False)
        self.window().refreshActorList()

    def set_background_color(self):

        if self.background == 'white':
            self.background = 'black'
        else:
            self.background = 'white'

        self.plotter.background_color = self.background

        self.window().ortho_viewer.set_background(self.background)

    def toggleColorBlind(self):

        self.color_blind = not self.color_blind
        self.update_trk_viewer()

    def set_view(self, method):
        getattr(self.plotter, method)()
        self.plotter.camera.azimuth += self.flicker * 180
        self.flicker = not self.flicker

    def take_screenshot(self):
        """Take a screenshot of the current 3D view."""
        options = QFileDialog.Options()
        file_path, _ = QFileDialog.getSaveFileName(self, "Save Screenshot", "",
                                                   "PNG Image (*.png);;JPEG Image (*.jpg);;TIFF Image (*.tif)",
                                                   options=options)
        if file_path:
            self.plotter.screenshot(file_path, transparent_background=True)

    def create_gif(self):
        """Create a 360° rotation GIF of the current 3D view."""
        options = QFileDialog.Options()
        file_path, _ = QFileDialog.getSaveFileName(self, "Save GIF", "",
                                                   "GIF Files (*.gif)",
                                                   options=options)

        if not file_path:
            return

        # Ensure the file has a .gif extension
        if not file_path.lower().endswith(".gif"):
            file_path += ".gif"

        # Use an offscreen plotter so the main one remains visible
        offscreen = pv.Plotter(
            off_screen=True, window_size=self.plotter.window_size)

        # Copy all meshes and volumes from the main plotter to the offscreen one
        for actor_name, actor in self.plotter.actors.items():
            offscreen.add_actor(actor)

        # Match background color and camera
        offscreen.background_color = self.plotter.background_color
        offscreen.camera_position = self.plotter.camera_position
        offscreen.camera.SetPosition(self.plotter.camera.GetPosition())
        offscreen.camera.SetFocalPoint(self.plotter.camera.GetFocalPoint())
        offscreen.camera.SetViewUp(self.plotter.camera.GetViewUp())

        # Create the 360° rotation GIF
        offscreen.open_gif(file_path, fps=20)
        n_frames = 360
        for i in range(n_frames):
            offscreen.camera.Azimuth(360 / n_frames)
            offscreen.render()
            offscreen.write_frame()
            self.plotter.camera.azimuth += 360 / n_frames
            self.plotter.render()
        offscreen.close()

    def on_nii_colormap_changed(self):
        self.update_nii_viewer()
        if hasattr(self.window(), 'ortho_viewer'):
            self.window().ortho_viewer.set_colormap(self.niiColorMapComboBox.currentText())

    def update_trk_viewer(self, reset_camera: bool = False):

        opacity = self.opacitySlider.value() / 100.0
        show_points = self.showPointsCheckbox.isChecked()

        color_mode = self.colorMapComboBox.currentText()
        if color_mode == 'flesh':
            color_map = 'flesh'
            scalar = None
        elif color_mode == 'rgb':
            color_map = 'plasma'
            scalar = None
        else:
            color_map = self.tractColorMapComboBox.currentText()
            scalar = self.nii_data

        for file in list(self.actor_types):

            if self.actor_types.get(file) == 'trk':

                plot_trk(file, opacity=opacity, plotter=self.plotter, scalar=scalar,
                         show_points=show_points, color_map=color_map,
                         name=file, background=self.background,
                         reset_camera=reset_camera, color_blind=self.color_blind)

    def _update_slice(self, axis, actor_name):

        if self.showSlicesCheckbox.isChecked() and self.grid is not None:

            center = (self.XSlider.value(), self.YSlider.value(),
                      self.ZSlider.value())

            slice_mesh = self.grid.slice(axis, origin=center)
            cmap_name = self.niiColorMapComboBox.currentText()

            self.plotter.add_mesh(slice_mesh, cmap=cmap_name, name=actor_name,
                                  show_scalar_bar=False, point_size=0,
                                  render_lines_as_tubes=True,
                                  reset_camera=False,
                                  user_matrix=self.nii_affine)

        else:
            self.plotter.remove_actor(actor_name)

    def update_nii_viewer(self, reset_camera: bool = False):
        if self.grid is None:
            return

        self._update_slice('x', 'nii_x')
        self._update_slice('y', 'nii_y')
        self._update_slice('z', 'nii_z')

        opacity = self.nii_opacitySlider.value()/1000
        cmap_name = self.niiColorMapComboBox.currentText()

        vmin = self.niiMinSpinBox.value()
        vmax = self.niiMaxSpinBox.value()

        # Protect against an invalid range
        if vmax <= vmin:
            vmax = vmin + 1e-6

        self.plotter.add_volume(self.grid, cmap=cmap_name, opacity=[0, opacity],
                                show_scalar_bar=False, name='nii_volume',
                                reset_camera=reset_camera, clim=[vmin, vmax],
                                user_matrix=self.nii_affine)

    def update_gii_viewer(self, reset_camera=False, update_color_range=False):
        """Update the GIFTI surface rendering."""

        if not hasattr(self, "gii_mesh"):
            return

        self.update_surface_color_controls()

        opacity = self.gii_opacitySlider.value() / 100.0

        color_mode = self.giiColorModeComboBox.currentText()

        if color_mode == "Solid":

            self.plotter.add_mesh(self.gii_mesh, color="ghostwhite",
                                  culling="back", smooth_shading=True,
                                  opacity=opacity, name="gii_surface",
                                  reset_camera=reset_camera,
                                  point_size=0, render_lines_as_tubes=True)

        else:
            if color_mode == "NIfTI values":
                scalars = self.nii_surface_values
            else:
                scalars = self.gii_data[color_mode]

            if scalars is None:
                self.plotter.add_mesh(self.gii_mesh, color="ghostwhite",
                                      culling="back", smooth_shading=True,
                                      opacity=opacity, name="gii_surface",
                                      reset_camera=reset_camera,
                                      point_size=0, render_lines_as_tubes=True)
                return

            # Copy the mesh so that the original GIFTI mesh is not modified
            surface_mesh = self.gii_mesh.copy(deep=True)
            surface_mesh.point_data[color_mode] = scalars

            cmap_name = self.giiColorMapComboBox.currentText()

            if update_color_range:
                self.update_surface_color_range(scalars)

            vmin = self.giiMinSpinBox.value()
            vmax = self.giiMaxSpinBox.value()

            # Protect against an invalid range
            if vmax <= vmin:
                vmax = vmin + 1e-6

            self.plotter.add_mesh(surface_mesh, scalars=color_mode,
                                  cmap=cmap_name, clim=[vmin, vmax],
                                  culling="back", smooth_shading=True,
                                  opacity=opacity, name="gii_surface",
                                  reset_camera=reset_camera, point_size=0,
                                  render_lines_as_tubes=True,
                                  show_scalar_bar=False)

        self.plotter.render()

    def update_volume_color_range_from_nifti(self):

        if self.nii_data is None:
            return

        data = np.asarray(self.nii_data, dtype=float)
        finite = np.isfinite(data)

        if not np.any(finite):
            return

        values = data[finite]

        vmin = float(np.min(values))
        vmax = float(np.max(values))

        # Avoid identical limits because PyVista/VTK does not like
        # clim=[x, x].
        if np.isclose(vmin, vmax):
            vmax = vmin + 1.0

        self.niiMinSpinBox.blockSignals(True)
        self.niiMaxSpinBox.blockSignals(True)

        self.niiMinSpinBox.setValue(vmin)
        self.niiMaxSpinBox.setValue(vmax)

        self.niiMinSpinBox.blockSignals(False)
        self.niiMaxSpinBox.blockSignals(False)

    def update_surface_color_range(self, data):

        if data is None:
            return

        data = np.asarray(data, dtype=float)
        finite = np.isfinite(data)

        if not np.any(finite):
            return

        values = data[finite]

        vmin = float(np.min(values))
        vmax = float(np.max(values))

        # Avoid identical limits because PyVista/VTK does not like
        # clim=[x, x].
        if np.isclose(vmin, vmax):
            vmax = vmin + 1.0

        self.giiMinSpinBox.blockSignals(True)
        self.giiMaxSpinBox.blockSignals(True)

        self.giiMinSpinBox.setValue(vmin)
        self.giiMaxSpinBox.setValue(vmax)

        self.giiMinSpinBox.blockSignals(False)
        self.giiMaxSpinBox.blockSignals(False)

    def sample_nifti_on_surface(self, mesh):
        """
        Trilinearly sample the NIfTI volume onto the surface.

        Vertices outside the NIfTI are assigned NaN.
        """

        if self.nii_data is None or not hasattr(self, "nii_affine"):
            return None

        volume = np.asarray(self.nii_data_dilated, dtype=np.float64)

        points_world = np.asarray(mesh.points, dtype=np.float64)

        inv_affine = np.linalg.inv(self.nii_affine)

        homogeneous = np.column_stack([
            points_world,
            np.ones(len(points_world))
        ])

        points_voxel = (homogeneous @ inv_affine.T)[:, :3]

        nx, ny, nz = volume.shape[:3]

        # Identify points that are actually inside the NIfTI
        inside = (
            (points_voxel[:, 0] >= 0) &
            (points_voxel[:, 0] <= nx - 1) &
            (points_voxel[:, 1] >= 0) &
            (points_voxel[:, 1] <= ny - 1) &
            (points_voxel[:, 2] >= 0) &
            (points_voxel[:, 2] <= nz - 1)
        )

        # Clip only for interpolation
        x = np.clip(points_voxel[:, 0], 0, nx - 1)
        y = np.clip(points_voxel[:, 1], 0, ny - 1)
        z = np.clip(points_voxel[:, 2], 0, nz - 1)

        x0 = np.floor(x).astype(int)
        y0 = np.floor(y).astype(int)
        z0 = np.floor(z).astype(int)

        x1 = np.minimum(x0 + 1, nx - 1)
        y1 = np.minimum(y0 + 1, ny - 1)
        z1 = np.minimum(z0 + 1, nz - 1)

        xd = x - x0
        yd = y - y0
        zd = z - z0

        c000 = volume[x0, y0, z0]
        c001 = volume[x0, y0, z1]
        c010 = volume[x0, y1, z0]
        c011 = volume[x0, y1, z1]

        c100 = volume[x1, y0, z0]
        c101 = volume[x1, y0, z1]
        c110 = volume[x1, y1, z0]
        c111 = volume[x1, y1, z1]

        c00 = c000 * (1 - xd) + c100 * xd
        c01 = c001 * (1 - xd) + c101 * xd
        c10 = c010 * (1 - xd) + c110 * xd
        c11 = c011 * (1 - xd) + c111 * xd

        c0 = c00 * (1 - yd) + c10 * yd
        c1 = c01 * (1 - yd) + c11 * yd

        values = c0 * (1 - zd) + c1 * zd

        # Outside the NIfTI = NaN
        values[~inside] = np.nan

        return values.astype(np.float32)

    def sample_nifti_on_surface2(self, mesh):
        """
        !!! Currently unused
        Sample the currently loaded NIfTI volume at every GIFTI surface vertex.

        GIFTI vertices are assumed to be in world/mm coordinates.
        The NIfTI affine is used to convert them into voxel coordinates.

        Nearest-neighbor sampling is used.
        """

        if self.nii_data is None:
            return None

        if not hasattr(self, 'nii_affine'):
            return None

        vertices_world = np.asarray(mesh.points)

        # Convert world coordinates -> NIfTI voxel coordinates
        inv_affine = np.linalg.inv(self.nii_affine)

        homogeneous = np.column_stack([
            vertices_world,
            np.ones(len(vertices_world))
        ])

        vertices_voxel = (homogeneous @ inv_affine.T)[:, :3]

        # Nearest-neighbor voxel coordinates
        vertices_voxel = np.rint(vertices_voxel).astype(int)

        shape = self.nii_data.shape

        # Determine which vertices are inside the NIfTI
        valid = (
            (vertices_voxel[:, 0] >= 0) &
            (vertices_voxel[:, 0] < shape[0]) &
            (vertices_voxel[:, 1] >= 0) &
            (vertices_voxel[:, 1] < shape[1]) &
            (vertices_voxel[:, 2] >= 0) &
            (vertices_voxel[:, 2] < shape[2])
        )

        # Initialize outside-of-volume vertices with NaN
        values = np.full(len(vertices_world), np.nan, dtype=np.float32)

        valid_voxels = vertices_voxel[valid]

        values[valid] = self.nii_data[
            valid_voxels[:, 0],
            valid_voxels[:, 1],
            valid_voxels[:, 2]
        ]

        return values

    def update_surface_color_controls(self):
        """Enable surface scalar controls only when using NIfTI values."""

        use_nifti = (self.giiColorModeComboBox.currentText()
                     != "Solid")

        self.giiColorMapLabel.setEnabled(use_nifti)
        self.giiColorMapComboBox.setEnabled(use_nifti)

        self.giiMinLabel.setEnabled(use_nifti)
        self.giiMinSpinBox.setEnabled(use_nifti)

        self.giiMaxLabel.setEnabled(use_nifti)
        self.giiMaxSpinBox.setEnabled(use_nifti)


class OrthogonalViewer(QWidget):

    def __init__(self):
        super().__init__()

        self.volume = None
        self.affine = None
        self.cmap = "gray"

        self.rois = {}
        self.roi_visibility = {}

        self.background = "white"

        layout = QVBoxLayout(self)

        toolbar = QHBoxLayout()

        btn_screenshot = QPushButton("Screenshot")
        btn_screenshot.clicked.connect(self.take_screenshot)

        toolbar.addStretch()
        toolbar.addWidget(btn_screenshot)

        layout.addLayout(toolbar)

        self.fig = Figure(figsize=(12, 4), layout='constrained')
        self.canvas = FigureCanvasQTAgg(self.fig)

        self.ax_axial = self.fig.add_subplot(131)
        self.ax_coronal = self.fig.add_subplot(132)
        self.ax_sagittal = self.fig.add_subplot(133)

        layout.addWidget(self.canvas)

        self.x = 0
        self.y = 0
        self.z = 0

        self.canvas.mpl_connect("scroll_event", self.on_scroll)
        self.canvas.mpl_connect("button_press_event", self.on_click)

    def set_volume(self, volume, affine=None):

        self.volume = volume
        self.affine = affine

        self.x = volume.shape[0] // 2
        self.y = volume.shape[1] // 2
        self.z = volume.shape[2] // 2

        self.update_views()

    def set_colormap(self, cmap_name):
        self.cmap = cmap_name
        self.update_views()

    def add_roi(self, name, roi, color):

        self.rois[name] = {"data": roi, "color": color}
        self.roi_visibility[name] = True
        self.update_views()

    def draw_roi(self, ax, roi_slice, color):

        if roi_slice.max() == 0:
            return

        ax.contour(roi_slice, levels=[0.5], colors=[color], linewidths=1.5,
                   antialiased=True)
        ax.contourf(roi_slice, levels=[0.5, roi_slice.max()+1], colors=[color],
                    alpha=0.5)

    def update_views(self):

        if self.volume is None:
            return

        x = self.x
        y = self.y
        z = self.z

        axial = self.volume[:, :, z]
        coronal = self.volume[:, y, :]
        sagittal = self.volume[x, :, :]

        self.ax_axial.clear()
        self.ax_coronal.clear()
        self.ax_sagittal.clear()

        for ax in (self.ax_axial, self.ax_coronal, self.ax_sagittal):
            ax.axis("off")

        self.ax_axial.imshow(np.rot90(axial), cmap=self.cmap, vmin=0)
        self.ax_coronal.imshow(np.rot90(coronal), cmap=self.cmap, vmin=0)
        self.ax_sagittal.imshow(np.rot90(sagittal), cmap=self.cmap, vmin=0)

        for name, roi_info in self.rois.items():

            if not self.roi_visibility[name]:
                continue

            roi = roi_info["data"]
            color = roi_info["color"]

            self.draw_roi(self.ax_axial, np.rot90(roi[:, :, z]), color)
            self.draw_roi(self.ax_coronal, np.rot90(roi[:, y, :]), color)
            self.draw_roi(self.ax_sagittal, np.rot90(roi[x, :, :]), color)

        self.canvas.draw_idle()

    def take_screenshot(self):

        options = QFileDialog.Options()

        file_path, _ = QFileDialog.getSaveFileName(self,
                                                   "Save Orthogonal View", "",
                                                   "PNG Image (*.png);;JPEG Image (*.jpg);;TIFF Image (*.tif);; SVG Image (*.svg)",
                                                   options=options
                                                   )

        if file_path:
            self.fig.savefig(file_path, dpi=300, transparent=True)

    def set_background(self, color):

        self.background = color

        self.fig.patch.set_facecolor(color)

        for ax in (self.ax_axial, self.ax_coronal, self.ax_sagittal):
            ax.set_facecolor(color)

        self.canvas.draw_idle()

    def on_scroll(self, event):

        if self.volume is None:
            return

        step = 1 if event.button == "up" else -1

        if event.inaxes == self.ax_axial:
            self.z = np.clip(self.z + step, 0, self.volume.shape[2]-1)

        elif event.inaxes == self.ax_coronal:
            self.y = np.clip(self.y + step, 0, self.volume.shape[1]-1)

        elif event.inaxes == self.ax_sagittal:
            self.x = np.clip(self.x + step, 0, self.volume.shape[0]-1)

        self.update_views()

    def on_click(self, event):

        if self.volume is None:
            return

        if event.inaxes is None:
            return

        if event.xdata is None or event.ydata is None:
            return

        col = int(round(event.xdata))
        row = int(round(event.ydata))

        if event.inaxes == self.ax_axial:

            self.x = np.clip(col, 0, self.volume.shape[0]-1)
            self.y = np.clip(
                self.volume.shape[1]-1-row, 0, self.volume.shape[1]-1)

        elif event.inaxes == self.ax_coronal:

            self.x = np.clip(col, 0, self.volume.shape[0]-1)
            self.z = np.clip(
                self.volume.shape[2]-1-row, 0, self.volume.shape[2]-1)

        elif event.inaxes == self.ax_sagittal:

            self.y = np.clip(col, 0, self.volume.shape[1]-1)
            self.z = np.clip(
                self.volume.shape[2]-1-row, 0, self.volume.shape[2]-1)

        self.update_views()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.tabs = QTabWidget()

        self.viewer = TrkViewer()
        self.ortho_viewer = OrthogonalViewer()

        self.tabs.addTab(self.viewer, "3D Viewer")
        self.tabs.addTab(self.ortho_viewer, "Orthogonal Viewer")

        self.setCentralWidget(self.tabs)
        self.initActorDock()
        self.initMenuBar()
        self.setWindowTitle("UNVEIL - Tractography Viewer")

    def initMenuBar(self):
        menubar = self.menuBar()

        # File menu
        fileMenu = menubar.addMenu('File')

        # Action to load .trk file
        loadTrkAction = QAction('Load .trk File', self)
        loadTrkAction.triggered.connect(self.viewer.loadTrkFile)
        fileMenu.addAction(loadTrkAction)

        # Action to load .nii.gz file
        loadNiftiAction = QAction('Load .nii.gz File', self)
        loadNiftiAction.triggered.connect(self.viewer.loadNiftiFile)
        fileMenu.addAction(loadNiftiAction)

        # Action to load .gii file
        loadGiftiAction = QAction('Load .gii File', self)
        loadGiftiAction.triggered.connect(self.viewer.loadGiftiFile)
        fileMenu.addAction(loadGiftiAction)

        # Load ROIs
        loadROIAction = QAction('Load ROIs (.nii/.nii.gz)', self)
        loadROIAction.triggered.connect(self.viewer.loadROIFile)
        fileMenu.addAction(loadROIAction)

        # Optional: Exit action
        exitAction = QAction('Exit', self)
        exitAction.triggered.connect(self.close)
        fileMenu.addAction(exitAction)

        # View menu
        viewMenu = menubar.addMenu('View')
        setBackColorAction = QAction('Background Color', self)
        setBackColorAction.triggered.connect(self.viewer.set_background_color)
        viewMenu.addAction(setBackColorAction)
        toggleActorListAction = QAction("Toggle Actor List", self,
                                        checkable=True)
        toggleActorListAction.triggered.connect(self.toggleActorDock)
        viewMenu.addAction(toggleActorListAction)
        toggleColorBlindAction = QAction("Use color-blind colors", self,
                                         checkable=True)
        toggleColorBlindAction.triggered.connect(self.viewer.toggleColorBlind)
        viewMenu.addAction(toggleColorBlindAction)

    def initActorDock(self):
        self.actorDock = QDockWidget("Scene Actors", self)
        self.actorDock.setAllowedAreas(Qt.DockWidgetArea.RightDockWidgetArea)

        self.actorTree = QTreeWidget()

        self.actorTree.setHeaderLabels(["Visible", "Color", "Actor"])
        self.actorTree.setColumnCount(3)
        self.actorTree.setIndentation(5)

        self.actorTree.setColumnWidth(0, 45)
        self.actorTree.setColumnWidth(1, 40)
        self.actorTree.setColumnWidth(2, 220)

        self.actorDock.setWidget(self.actorTree)
        self.addDockWidget(
            Qt.DockWidgetArea.RightDockWidgetArea, self.actorDock)

        self.actorDock.hide()  # start hidden

        # Refresh the list whenever actors change
        self.viewer.plotter.mesh_added_callback = self.refreshActorList
        self.viewer.plotter.mesh_removed_callback = self.refreshActorList

        self.actorTree.itemDoubleClicked.connect(self.changeActorColor)

        # Connect visibility toggles
        self.actorTree.itemChanged.connect(self.onActorVisibilityChanged)

    def toggleActorDock(self, checked):
        if checked:
            self.actorDock.show()
        else:
            self.actorDock.hide()

    def refreshActorList(self):
        """Rebuild the hierarchical actor list grouped by class."""
        self.actorTree.blockSignals(True)
        self.actorTree.clear()

        # Groups
        group_trk = QTreeWidgetItem(["TRK", ""])
        group_nii = QTreeWidgetItem(["NIfTI Volume", ""])
        group_roi = QTreeWidgetItem(["ROI Surfaces", ""])
        group_gii = QTreeWidgetItem(["GIFTI", ""])

        self.actorTree.addTopLevelItem(group_trk)
        self.actorTree.addTopLevelItem(group_nii)
        self.actorTree.addTopLevelItem(group_gii)
        self.actorTree.addTopLevelItem(group_roi)
        # Loop through PyVista actors
        for name, actor in self.viewer.plotter.actors.items():

            item = QTreeWidgetItem(["", "", name])

            item.setCheckState(0, Qt.CheckState.Checked if actor.GetVisibility()
                               else Qt.CheckState.Unchecked)

            # Store name for callback
            item.actor_name = name

            if self.viewer.actor_types.get(name) == 'roi':

                rgb = self.viewer.roi_colors.get(name, (1, 1, 1))

                qcolor = QColor(int(rgb[0] * 255), int(rgb[1] * 255),
                                int(rgb[2] * 255))
                item.setBackground(1, qcolor)

            # Insert into the correct group
            if self.viewer.actor_types.get(name) == 'trk':
                group_trk.addChild(item)
            elif name.startswith("nii_"):
                group_nii.addChild(item)
            elif name.startswith("gii_"):
                group_gii.addChild(item)
            elif self.viewer.actor_types.get(name) == 'roi':
                group_roi.addChild(item)
            else:
                group_trk.addChild(item)  # default bucket

        self.actorTree.blockSignals(False)

    def onActorVisibilityChanged(self, item, column):
        """Toggle visibility when user clicks checkbox."""
        if column != 0:
            return

        actor_name = item.actor_name
        visible = item.checkState(0) == Qt.CheckState.Checked

        try:
            self.viewer.plotter.actors[actor_name].SetVisibility(visible)
        except KeyError:
            pass

        self.viewer.roi_visibility[actor_name] = visible
        self.ortho_viewer.roi_visibility[actor_name] = visible
        self.ortho_viewer.update_views()

        self.viewer.plotter.render()

    def changeActorColor(self, item, column):

        if column != 1:
            return

        actor_name = getattr(item, "actor_name", None)

        if actor_name is None:
            return

        if self.viewer.actor_types.get(actor_name) != "roi":
            return

        color = QColorDialog.getColor()

        if not color.isValid():
            return

        rgb = (color.red() / 255, color.green() / 255, color.blue() / 255)

        self.viewer.roi_colors[actor_name] = rgb
        if actor_name in self.ortho_viewer.rois:
            self.ortho_viewer.rois[actor_name]["color"] = rgb
            self.ortho_viewer.update_views()

        item.setBackground(1, color)

        try:
            actor = self.viewer.plotter.actors[actor_name]
            actor.GetProperty().SetColor(*rgb)
            self.viewer.plotter.render()

        except Exception:
            pass


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
